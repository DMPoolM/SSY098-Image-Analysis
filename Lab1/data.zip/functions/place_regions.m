function region_centres = place_regions(centre, radius)
    % Initialize region centres array
    region_centres = zeros(2, 9);

    % Define offsets for placing regions
    offsets = [-1, 0, 1];

    % Generate region centres
    k = 0;
    for i = 1:3
        for j = 1:3
            % Compute coordinates of the current region centre
            x = centre(1) + 2*offsets(i) * radius;
            y = centre(2) + 2*offsets(j) * radius;
            k = k + 1;
            region_centres(:, k) = [x; y];
        end
    end
end
