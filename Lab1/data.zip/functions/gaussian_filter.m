function result = gaussian_filter(image, sigma)
    % Ensure the image is in double format
    image = double(image);

    % Calculate filter size to cover at least four standard deviations
    filter_size = ceil(4 * sigma);

    % Construct a Gaussian filter
    gaussian_filter = fspecial('gaussian', [filter_size filter_size], sigma);

    % Apply the filter to the image
    result = imfilter(image, gaussian_filter, 'symmetric');
end
