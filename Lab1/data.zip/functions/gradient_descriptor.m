function desc = gradient_descriptor(image, position, radius)
    % Compute standard deviation proportional to radius
    std = 0.2 * radius;

    % Compute gaussian gradients
    [grad_x, grad_y] = gaussian_gradients(image, std);

    % Define 3 x 3 regions around the position
    region_centres = place_regions(position, radius);

    % Initialize descriptor vector
    desc = zeros(1, 72);

    % Compute gradient histograms for each region
    for i = 1:size(region_centres, 2)
        % Get coordinates of the region center
        x = round(region_centres(1, i));
        y = round(region_centres(2, i));

        % Extract gradient patches for the current region
        patch_grad_x = get_patch(grad_x, x, y, radius);
        patch_grad_y = get_patch(grad_y, x, y, radius);

        % Compute gradient histogram for the current region
        histogram = gradient_histogram(patch_grad_x, patch_grad_y);

        % Stack the histogram into the descriptor vector
        start_index = (i - 1) * 8 + 1;
        end_index = i * 8;
        desc(start_index:end_index) = histogram;
    end

    % Normalize the descriptor vector to unit length
    desc = desc / norm(desc);
end
