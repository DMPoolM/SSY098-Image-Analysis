function [grad_x, grad_y] = gaussian_gradients(img, std)
    % Ensure the image is in double format
    img = double(img);

    % Calculate filter size to cover at least four standard deviations
    filter_size = ceil(4 * std);

    % Construct derivative filters
    % Derivative filter for gradient in x direction
    dx_filter = [-1 0 1];
    % Derivative filter for gradient in y direction
    dy_filter = [-1; 0; 1];

    % Apply Gaussian filter to the image
    img_smoothed = gaussian_filter(img, std);

    % Apply derivative filters to the smoothed image to compute gradients
    grad_x = imfilter(img_smoothed, dx_filter, 'conv', 'symmetric');
    grad_y = imfilter(img_smoothed, dy_filter, 'conv', 'symmetric');
end