function patch = get_patch(image, x, y, patch_radius)
    % Check if the image is grayscale or color
   
        [rows, cols] = size(image);
        % Define patch boundaries
        x_start = max(1, x - patch_radius);
        x_end = min(rows, x + patch_radius);
        y_start = max(1, y - patch_radius);
        y_end = min(cols, y + patch_radius);
        % Extract the patch
        patch = image(x_start:x_end, y_start:y_end);
end
