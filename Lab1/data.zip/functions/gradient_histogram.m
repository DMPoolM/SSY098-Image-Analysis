function histogram = gradient_histogram(grad_x, grad_y)
    % Calculate gradient magnitudes and orientations
    grad_magnitude = sqrt(grad_x.^2 + grad_y.^2);
    grad_orientation = atan2(grad_y, grad_x);

    % Define the bins and bin order
    bins = [-pi+pi/8:pi/4:pi-pi/8]; % Bins for 8 orientations
    bin_order = [5 6 7 8 1 2 3 4]; % Bin order as per lecture notes

    % Initialize histogram
    histogram = zeros(1, 8);

    % Place each gradient into one of the eight orientation bins
    for i = 1:numel(grad_orientation)
        orientation = grad_orientation(i);
        magnitude = grad_magnitude(i);
        % Find the bin index
        [~, bin_index] = min(abs(orientation - bins));
        % Update histogram
        histogram(bin_order(bin_index)) = histogram(bin_order(bin_index)) + magnitude;
    end
end