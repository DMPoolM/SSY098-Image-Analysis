
% Choose center and radius parameters
centre = [15; 15];
radius = 10;

% Initialize variables to count correct classifications
correct_count = 0;

% Classify each digit in digits_validation
for i = 1:numel(digits_validation)
    % Get the digit image
    digit_image = digits_validation(i).image;
    
    % Get the true label of the digit
    true_label = digits_validation(i).label;
    
    % Classify the digit
    classified_label = classify_digit(digit_image, digits_training, centre, radius);
    
    % Check if the classification is correct
    if classified_label == true_label
        correct_count = correct_count + 1;
    end
end

% Calculate the percentage of correct answers
accuracy = correct_count / numel(digits_validation) * 100;

% Display the percentage of correct answers
disp(['Percentage of correct answers: ', num2str(accuracy), '%']);
