% Define parameters for computing descriptors
radius = 10; % Choose a radius that fits well within the images
position = [20; 20]; % Choose a position within the image

% Compute descriptors for each digit in digits_training
for i = 1:numel(digits_training)
    % Get the image from digits_training
    img = digits_training(i).image;
    
    % Compute the descriptor for the current digit
    desc = gradient_descriptor(img, position, radius);
    
    % Store the descriptor in digits_training
    digits_training(i).descriptor = desc;
end
